Anomia Odd-Man-Out Test Sets
----------------------------

This collection consists of four sets of "odd-man-out" puzzles. Each puzzle is a single line in the following tab-separated value format:

CATEGORY <tab> ODD-MAN <tab> ANSWER1 <tab> ANSWER2 <tab> ANSWER3 <tab> ANSWER4

Many of the categories are taken from the card game Anomia, which was used to drive the puzzle generation process.

There are two collections of "common noun" puzzles, where the answer options are largely common nouns, and
two collections of "proper noun" puzzles, where the answers options are largely proper nouns. Each collection
contains approximately 100 puzzles.


